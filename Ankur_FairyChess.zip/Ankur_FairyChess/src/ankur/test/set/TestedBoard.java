package ankur.test.set;

import ankur.test.design.board.BoardTest;
import ankur.test.design.board.ChessBoardTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Ankur Lamichhane
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({BoardTest.class, ChessBoardTest.class})
public class TestedBoard {
}