package ankur.test.set;

import ankur.test.design.piece.RookTest;
import ankur.test.design.piece.PawnTest;
import ankur.test.design.piece.KnightTest;
import ankur.test.design.piece.QueenTest;
import ankur.test.design.piece.KingTest;
import ankur.test.design.piece.BishopTest;
import ankur.test.design.piece.PieceTest;
import ankur.test.design.piece.PrincessTest;
import ankur.test.design.piece.EmpressTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Ankur Lamichhane
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({PieceTest.class, PawnTest.class, RookTest.class, BishopTest.class, KnightTest.class, QueenTest
        .class, EmpressTest.class, PrincessTest.class, KingTest.class})
public class TestedPiece {

}