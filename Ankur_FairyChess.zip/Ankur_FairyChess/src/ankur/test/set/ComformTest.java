package ankur.test.set;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Ankur Lamichhane
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({TestedBoard.class, TestedPiece.class})
public class ComformTest {

}