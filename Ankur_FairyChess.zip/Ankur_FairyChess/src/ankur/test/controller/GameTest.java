package ankur.test.controller;

import org.junit.Before;

public class GameTest {

    @Before
    public void setUp() throws Exception {

    }
}