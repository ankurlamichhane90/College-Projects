package ankur.test.design.piece;

import ankur.game.design.piece.Princess;
import org.junit.Test;

/**
 *
 * @author Ankur Lamichhane
 */
public class PrincessTest {

    /**
     * Tests if the path to the Princess's image is correct. The test path is gathered directly from the image using
     * Ctrl+Shift+C.
     */
    @Test
    public void testImageGathering() {
        Princess testBlackPrincess = new Princess(true);
        Princess testWhitePrincess = new Princess(false);
        assert testBlackPrincess.getPathToImage().equals("src/chess/view/img/black_princess.png");
        assert testWhitePrincess.getPathToImage().equals("src/chess/view/img/white_princess.png");
    }

}