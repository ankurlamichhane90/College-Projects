package ankur.test.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.ChessBoard;
import ankur.game.design.piece.King;
import ankur.game.design.piece.Queen;
import ankur.game.design.piece.Rook;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author Ankur Lamichhane
 */
public class KingTest {

    private Board testBoard;
    private King testBlackKing;
    private King testWhiteKing;

    /**
     * Creates an empty, not-for-playing chessboard for testing purposes, creating kings in both extremes of the board.
     * Setting them up like this helps verifying check/checkmate conditions.
     */
    @Before
    public void setUp() {
        testBoard = new ChessBoard();
        testBlackKing = new King(true);
        testWhiteKing = new King(false);
        testBoard.putPieceAt(testBlackKing, 7, 7);
        testBoard.putPieceAt(testWhiteKing, 0, 0);
    }

    /**
     * Tests if the path to the King's image is correct. The test path is gathered directly from the image using
     * 
     */
    @Test
    public void testImageGathering() {
        assert testBlackKing.getPathToImage().equals("src/chess/view/img/black_king.png");
        assert testWhiteKing.getPathToImage().equals("src/chess/view/img/white_king.png");
    }

    /**
     * Tests a situation where both kings are out of threat on the board.
     */
    @Test
    public void testKingWithoutThreat() {
        Queen testBlackQueen = new Queen(true);
        Queen testWhiteQueen = new Queen(false);
        testBoard.putPieceAt(testBlackQueen, 3, 4);
        testBoard.putPieceAt(testWhiteQueen, 4, 2);
        assert testBlackKing.isInCheck();
        assert testWhiteKing.isInCheck();
    }

    /**
     * Tests a situation where one of the kings is in check on the board.
     */
    @Test
    public void testKingInCheck() {
        Queen testBlackQueen = new Queen(true);
        Queen testWhiteQueen = new Queen(false);
        testBoard.putPieceAt(testBlackQueen, 3, 4);
        testBoard.putPieceAt(testWhiteQueen, 0, 7);
        assert testBlackKing.isInCheck();
        assert testWhiteKing.isInCheck();
    }

    /**
     * Tests a situation where one of the kings is in check, but can capture the piece.
     */
    @Test
    public void testKingInCheckButCanCapture() {
        Queen testBlackQueen = new Queen(true);
        Queen testWhiteQueen = new Queen(false);
        testBoard.putPieceAt(testBlackQueen, 3, 4);
        testBoard.putPieceAt(testWhiteQueen, 6, 6);
        assert testBlackKing.isInCheck();
        assert testWhiteKing.isInCheck();
        assert testBlackKing.canMoveTo(testBoard.getSquareAt(6, 6));
    }

    /**
     * Tests a situation where one of the kings is in checkmate on the board.
     */
    @Test
    public void testKingInCheckMate() {
        Rook testBlackRook = new Rook(true);
        Rook testWhiteRook = new Rook(false);
        Queen testWhiteQueen = new Queen(false);
        testBoard.putPieceAt(testBlackRook, 3, 4);
        testBoard.putPieceAt(testWhiteRook, 0, 6);
        testBoard.putPieceAt(testWhiteQueen, 0, 7);
        assert testWhiteKing.isInCheck();
        assert testBlackKing.isInCheck();
        assert testBlackKing.isInCheckMate();
    }

}