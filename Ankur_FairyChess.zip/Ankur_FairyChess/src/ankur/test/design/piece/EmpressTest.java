package ankur.test.design.piece;

import ankur.game.design.piece.Empress;
import org.junit.Test;

/**
 *
 * @author Ankur Lamichhane
 */
public class EmpressTest {

    /**
     * Tests if the path to the Empress's image is correct. The test path is gathered directly from the image using
     * 
     */
    @Test
    public void testImageGathering() {
        Empress testBlackEmpress = new Empress(true);
        Empress testWhiteEmpress = new Empress(false);
        assert testBlackEmpress.getPathToImage().equals("src/chess/view/img/black_empress.png");
        assert testWhiteEmpress.getPathToImage().equals("src/chess/view/img/white_empress.png");
    }

}