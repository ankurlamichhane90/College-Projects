package ankur.test.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.ChessBoard;
import ankur.game.design.piece.Bishop;
import org.junit.Before;
import org.junit.Test;
/**
 *
 * @author Ankur Lamichhane
 */
public class BishopTest {

    private Board testBoard;

    /**
     * Creates an empty, not-for-playing chessboard for testing purposes. It is non-static because a static instance of
     * the board would have pieces being placed without control.
     */
    @Before
    public void setUp() {
        testBoard = new ChessBoard();
    }

    /**
     * Tests if the path to the Bishop's image is correct. The test path is gathered directly from the image using
     * Ctrl+Shift+C.
     */
    @Test
    public void testImageGathering() {
        Bishop testBlackBishop = new Bishop(true);
        Bishop testWhiteBishop = new Bishop(false);
        assert testBlackBishop.getPathToImage().equals("src/chess/view/img/black_bishop.png");
        assert testWhiteBishop.getPathToImage().equals("src/chess/view/img/white_bishop.png");
    }

    /**
     * Tests if a bishop can move diagonally at any direction.
     */
    @Test
    public void testDiagonalMoves() {
        Bishop testBishop = new Bishop(true);
        testBoard.putPieceAt(testBishop, 3, 3);
        assert !testBishop.canMoveTo(testBoard.getSquareAt(3, 3));
        for (int dist = 1; dist < 4; dist++) {
            assert testBishop.canMoveTo(testBoard.getSquareAt(3 + dist, 3 + dist));
            assert testBishop.canMoveTo(testBoard.getSquareAt(3 + dist, 3 - dist));
            assert testBishop.canMoveTo(testBoard.getSquareAt(3 - dist, 3 + dist));
            assert testBishop.canMoveTo(testBoard.getSquareAt(3 - dist, 3 - dist));
        }
    }

    /**
     * Tests if a bishop cannot move forward when a same-player piece is in the way.
     */
    @Test
    public void testPlayerPieceBlock() {
        Bishop testBishopOne = new Bishop(true);
        Bishop testBishopTwo = new Bishop(true);
        testBoard.putPieceAt(testBishopTwo, 3, 3);
        testBoard.putPieceAt(testBishopOne, 0, 0);
        assert testBishopOne.canMoveTo(testBoard.getSquareAt(1, 1));
        assert testBishopOne.canMoveTo(testBoard.getSquareAt(2, 2));
        assert !testBishopOne.canMoveTo(testBoard.getSquareAt(3, 3));
        assert !testBishopOne.canMoveTo(testBoard.getSquareAt(4, 4));
    }

    /**
     * Tests if a bishop cannot move forward when an opponent piece is in the way.
     */
    @Test
    public void testOpponentPieceBlock() {
        Bishop testBlackBishop = new Bishop(true);
        Bishop testWhiteBishop = new Bishop(false);
        testBoard.putPieceAt(testWhiteBishop, 3, 3);
        testBoard.putPieceAt(testBlackBishop, 0, 0);
        assert testBlackBishop.canMoveTo(testBoard.getSquareAt(1, 1));
        assert testBlackBishop.canMoveTo(testBoard.getSquareAt(2, 2));
        assert testBlackBishop.canMoveTo(testBoard.getSquareAt(3, 3));
        assert !testBlackBishop.canMoveTo(testBoard.getSquareAt(4, 4));
    }


}