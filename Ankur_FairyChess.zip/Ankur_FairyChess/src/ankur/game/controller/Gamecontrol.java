package ankur.game.controller;

import ankur.game.design.board.Board;
import ankur.game.design.board.ChessBoard;
import ankur.game.design.board.Square;
import ankur.game.design.piece.Piece;
import ankur.game.view.gui.BoardGUI;
import ankur.game.view.gui.ChessBoardInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Gamecontrol {

    private final BoardGUI gameGUI;
    private JFrame chessFrame;
    private Square chosenSquare;
    private boolean aPieceWasSelected;
    private boolean blackTurn;

    private void setFrame() {
        chessFrame = new JFrame("♚ Chess Game ♔");
        chessFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        chessFrame.setSize(screenSize);
        chessFrame.setResizable(true);
        chessFrame.setLocation(340, 60);
        chessFrame.setVisible(true);
    }

    public Gamecontrol() {
        Board gameBoard = new ChessBoard();
        gameBoard.setupPieces();
        gameGUI = new ChessBoardInterface(gameBoard);
        aPieceWasSelected = false;
        chosenSquare = null;
        blackTurn = false;
        setFrame();
        fillFrame();
    }
    
    public static void main(String[] args) {
        Gamecontrol chessGame = new Gamecontrol();
        chessGame.defineMouseListener();
        chessGame.addListenerToOtherButtons();
        chessGame.chessFrame.setVisible(true);
    }
    
    private void fillFrame() {
        JSplitPane gamePanel = gameGUI.getChessPanel();
        chessFrame.add(gamePanel);
    }

private void defineMouseListener() {
for (int posX = 0; posX < 8; posX++) {
    for (int posY = 0; posY < 8; posY++) {
        final JButton button = gameGUI.getButtonAt(posX, posY);
        final int xPos = posX;
        final int yPos = posY;
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!aPieceWasSelected) {
                    if (!gameGUI.hasPieceAt(xPos, yPos)) {
                        noPiece();
                    } else {
                        if (gameGUI.getPieceAt(xPos, yPos).isBlack() == blackTurn) {
                            foundPieceIn(button, xPos, yPos);
                        } else {
                            wrongPieceColor();
                        }
                    }
                } 
    else {
                Square newSquare = gameGUI.getSquareAt(xPos, yPos);
                if (newSquare != chosenSquare) {
                    if (chosenSquare.getSquarePiece().canMoveTo(newSquare)) {
                        movePieceTo(xPos, yPos);
                    } else {
                        if (newSquare.getSquarePiece() == null) {
                            cannotMoveThere();
                        } else {
                            if (newSquare.getSquarePiece().isBlack() != blackTurn) {
                                wrongPieceColor();
                            } else {
                                choseNewPieceIn(button, newSquare);
                            }
                        }
                    }
                } 
        else {
                        cleanBoardAndReferences();

                    }
                }
            }
        });
        }
    }
}

    private void addRestartListener() {
        final JButton restart = gameGUI.getRestart();
        restart.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }
        });
    }

  
    private void cleanBoardAndReferences() {
        gameGUI.originalPainting();
        chosenSquare = null;
        aPieceWasSelected = false;
    }

    private void foundPieceIn(JButton button, int xPos, int yPos) {
        aPieceWasSelected = true;
        chosenSquare = gameGUI.getSquareAt(xPos, yPos);
        gameGUI.paintMovesOf(chosenSquare.getSquarePiece());
        button.setBackground(Color.CYAN);
        gameGUI.setMessage("One of your pieces was selected.");
    }

  
    private void choseNewPieceIn(JButton button, Square newSquare) {
        chosenSquare = newSquare;
        gameGUI.originalPainting();
        gameGUI.paintMovesOf(chosenSquare.getSquarePiece());
        button.setBackground(Color.CYAN);
    }

    
    private void movePieceTo(int xPos, int yPos) {
        final Piece movingPiece = chosenSquare.getSquarePiece();
        movingPiece.moveTo(xPos, yPos);
        cleanBoardAndReferences();
        blackTurn = !blackTurn;
        gameGUI.changeTurn(blackTurn);
    }
   
    private void addListenerToOtherButtons() {
       
        addRestartListener();
    }

  
     private String playerColorCapitalized() {
        return blackTurn ? "Black " : "White ";
    }

 
    private void wrongPieceColor() {
        gameGUI.setMessage("You tried to move an opponent's piece. "
                + "You can only move " + playerColorLowercase()
                + "pieces.");
    }

    /**
     * gives a message on not having selected a piece.
     */
    private void noPiece() {
        gameGUI.setMessage("You did not select one of your pieces yet.");
    }
   private String playerColorLowercase() {
        return playerColorCapitalized().toLowerCase();
    }

    private void cannotMoveThere() {
        gameGUI.setMessage("Your piece cannot move to the selected square.");
    }
}
