package ankur.game.design.board;

import ankur.game.design.piece.Rook;
import ankur.game.design.piece.Fairy;
import ankur.game.design.piece.Bishop;
import ankur.game.design.piece.Empress;
import ankur.game.design.piece.Grasshopper;
import ankur.game.design.piece.Piece;
import ankur.game.design.piece.Queen;
import ankur.game.design.piece.King;
import ankur.game.design.piece.Knight;
import ankur.game.design.piece.Pawn;
import ankur.game.design.piece.Princess;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author Ankur Lamichhane
 */
public class ChessBoard extends Board {

    private static final int ROW_COUNT = 8, COLUMN_COUNT = 8;

    /**
     * Creates the chessboard as stated on the abstract parent Board.
     */
    public ChessBoard() {
        super();
    }

    /**
     * Sets up the board as a 8x8 matrix of squares.
     */
    protected void setupSquares() {
        squareBoard = new Square[COLUMN_COUNT][ROW_COUNT];
        for (int posX = 0; posX < squareBoard.length; posX++)
            for (int posY = 0; posY < squareBoard[posX].length; posY++)
                squareBoard[posX][posY] = new Square(posX, posY);
    }

    /**
     * Checks if the parity of two numbers is equal.
     *
     * @param a first integer number.
     * @param b second integer number.
     * @return true if a+b is even.
     */
    private boolean checkParity(int a, int b) {
        return (a + b) % 2 == 0;
    }

    /**
     * Paints a square with the color LIGHT_GRAY.
     *
     * @param posX desired X-coordinate of a square.
     * @param posY desired Y-coordinate of a square.
     */
    private void paintBlue(int posX, int posY) {
        squareBoard[posX][posY].squareColor = Color.BLUE;
    }

    /**
     * Paints a square with the color WHITE.
     *
     * @param posX desired X-coordinate of a square.
     * @param posY desired Y-coordinate of a square.
     */
    private void paintWhite(int posX, int posY) {
        squareBoard[posX][posY].squareColor = Color.WHITE;
    }

    /**
     * Paints a square either LIGHT_GRAY or WHITE, based on the parity of the coordinates. On the traditional
     * chessboard, if the coordinates of a square have the same parity, the square is painted LIGHT_GRAY (or any dark
     * color).
     *
     * @param posX desired X-coordinate of a square.
     * @param posY desired Y-coordinate of a square.
     */
    protected void paintSquareAt(int posX, int posY) {
        if (checkParity(posX, posY))
            paintBlue(posX, posY);
        else paintWhite(posX, posY);
    }

    /**
     * Paints each square in the board according to the chessboard specifications. Implementation of Board's abstract
     * method.
     */
    @Override
    protected void paintSquares() {
        for (int posX = 0; posX < COLUMN_COUNT; posX++)
            for (int posY = 0; posY < ROW_COUNT; posY++)
                paintSquareAt(posX, posY);
    }

    /**
     * Sets up the traditional chessboard, which has a row of pawns defending a row of specific pieces: Rook - Knight -
     * Bishop - Queen - King - Bishop - Knight - Rook.
     */
    public void setupPieces() {
        for (int posX = 0; posX < COLUMN_COUNT; posX++) {
            putPieceAt(new Pawn(false), posX, 1);   // White pawns
            putPieceAt(new Pawn(true), posX, 6);    // Black pawns
        }

        // White pieces
         ArrayList<Integer> randPlaceForWhite = new ArrayList<Integer>();
        for (int i=0; i<8; i++) {
            randPlaceForWhite.add(new Integer(i));
        }
        Collections.shuffle(randPlaceForWhite);
        
        ArrayList<Piece> randPieceWhite = new ArrayList<>();
        randPieceWhite.add(new Empress(false));
        randPieceWhite.add(new Knight(false));
        randPieceWhite.add(new Bishop(false));
        randPieceWhite.add(new Queen(false));
        randPieceWhite.add(new Bishop(false));
        randPieceWhite.add(new Knight(false));
        randPieceWhite.add(new Rook(false));
        randPieceWhite.add(new Rook(false));
        randPieceWhite.add(new Princess(false));
        randPieceWhite.add(new Grasshopper(false));
        
        Collections.shuffle(randPieceWhite);
        randPieceWhite.remove(0);
        randPieceWhite.add(0, new Fairy(false));
        
        putPieceAt(randPieceWhite.get(0), randPlaceForWhite.get(0), 0);
        putPieceAt(randPieceWhite.get(1), randPlaceForWhite.get(1), 0);
        putPieceAt(randPieceWhite.get(2), randPlaceForWhite.get(2), 0);
        putPieceAt(randPieceWhite.get(3), randPlaceForWhite.get(3), 0);
        putPieceAt(new King(false), randPlaceForWhite.get(4), 0);
        putPieceAt(randPieceWhite.get(4), randPlaceForWhite.get(5), 0);
        putPieceAt(randPieceWhite.get(5), randPlaceForWhite.get(6), 0);
        putPieceAt(randPieceWhite.get(6), randPlaceForWhite.get(7), 0);
    
        // Black pieces
        ArrayList<Integer> randPlaceForBlack = new ArrayList<Integer>();
        for (int i=0; i<8; i++) {
            randPlaceForBlack.add(new Integer(i));
        }
        Collections.shuffle(randPlaceForBlack);
        //for removing a random black piece for fairy
        ArrayList<Piece> randPieceBlack = new ArrayList<>();
        randPieceBlack.add(new Rook(true));
        randPieceBlack.add(new Knight(true));
        randPieceBlack.add(new Bishop(true));
        randPieceBlack.add(new Queen(true));
        randPieceBlack.add(new Bishop(true));
        randPieceBlack.add(new Knight(true));
        randPieceBlack.add(new Rook(true));
        randPieceBlack.add(new Empress(true));
        randPieceBlack.add(new Princess(true));
        randPieceBlack.add(new Grasshopper(true));
        
        Collections.shuffle(randPieceBlack);
        randPieceBlack.remove(0);
        randPieceBlack.add(0, new Fairy(true));
        
        putPieceAt(randPieceBlack.get(0), randPlaceForBlack.get(0), 7);
        putPieceAt(randPieceBlack.get(1), randPlaceForBlack.get(1), 7);
        putPieceAt(randPieceBlack.get(2), randPlaceForBlack.get(2), 7);
        putPieceAt(randPieceBlack.get(3), randPlaceForBlack.get(3), 7);
        putPieceAt(new King(true), randPlaceForBlack.get(4), 7);
        putPieceAt(randPieceBlack.get(4), randPlaceForBlack.get(5), 7);
        putPieceAt(randPieceBlack.get(5), randPlaceForBlack.get(6), 7);
        putPieceAt(randPieceBlack.get(6), randPlaceForBlack.get(7), 7);
        
     

        // Sets flag for GUI - if those pieces are in play, no other piece should be added

        gameFlag = true;
    }

    /**
     * Says if an X-coordinate is out of bounds on the board.
     *
     * @param posX desired X-coordinate of a square.
     * @return <em>true</em> if the X-coordinate is out of bounds.
     */
    @Override
    public boolean xPosOutOfBounds(int posX) {
        return posX < 0 || posX >= COLUMN_COUNT;
    }

    /**
     * Says if a Y-coordinate is out of bounds on the board.
     *
     * @param posY desired Y-coordinate of a square.
     * @return <em>true</em> if the Y-coordinate is out of bounds.
     */
    @Override
    public boolean yPosOutOfBounds(int posY) {
        return posY < 0 || posY >= ROW_COUNT;
    }

}
