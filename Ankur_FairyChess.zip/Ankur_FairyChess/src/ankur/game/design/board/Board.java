package ankur.game.design.board;

import ankur.exceptionhandling.ExceptionPieceExist;
import ankur.exceptionhandling.ExceptionInGame;
import ankur.exceptionhandling.ExceptionPieceInPlace;
import ankur.game.design.piece.Piece;

import java.awt.*;

/**
 *
 * @author Ankur Lamichhane
 */
public abstract class Board {

    protected Square[][] squareBoard;
    protected boolean gameFlag;

    
    public Board() {
        setupSquares();
        paintSquares();
        gameFlag = false;
    }

   
    protected abstract void setupSquares();

    
    protected abstract void paintSquares();

    public abstract void setupPieces();

   
    public boolean hasSquareAt(int targetX, int targetY) {
        return !(xPosOutOfBounds(targetX) || yPosOutOfBounds(targetY)) && squareBoard[targetX][targetY] != null;
    }

    
    public Square getSquareAt(int posX, int posY) {
        return squareBoard[posX][posY];
    }

   
    public boolean hasPieceAt(int posX, int posY) {
        return !(xPosOutOfBounds(posX) || yPosOutOfBounds(posY)) && squareBoard[posX][posY].getSquarePiece() != null;
    }

   
    public void putPieceAt(Piece piece, int posX, int posY) {
        if (isInGame())
            throw new ExceptionInGame("You tried to set a piece when a game is already being played");
        if (alreadyHasPieceOnBoard(piece))
            throw new ExceptionPieceExist("You tried to add the same piece twice on the board");
        if (hasPieceAt(posX, posY))
            throw new ExceptionPieceInPlace("You tried to set a piece on the same place as another piece");
        squareBoard[posX][posY].squarePiece = piece;
        piece.learnMoveSetFrom(squareBoard[posX][posY], this);
        updateAllPieces();
    }

   
    public void movePieceTo(Square originalSquare, int posX, int posY) {
        squareBoard[posX][posY].squarePiece = originalSquare.getSquarePiece();
        originalSquare.squarePiece = null;
        updateAllPieces();
    }

    
    private void updateAllPieces() {
        for (Square[] squareArray : squareBoard) {
            for (Square square : squareArray) {
                if (square.getSquarePiece() != null) {
                    square.getSquarePiece().updateMoveSet();
                }
            }
        }
    }

    
    public Piece getPieceAt(int posX, int posY) {
        return squareBoard[posX][posY].getSquarePiece();
    }

    
    public boolean isInGame() {
        return gameFlag;
    }

   
    public boolean alreadyHasPieceOnBoard(Piece piece) {
        for (Square[] squareArray : squareBoard) {
            for (Square square : squareArray) {
                if (square.getSquarePiece() == piece)
                    return true;
            }
        }
        return false;
    }

   
    public abstract boolean xPosOutOfBounds(int posX);

    public abstract boolean yPosOutOfBounds(int posY);

    public void showAvailableMovesOf(Piece selectedPiece) {
        for (Square[] squareArray : squareBoard) {
            for (final Square s : squareArray) {
                if (selectedPiece.canMoveTo(s)) {
                    s.squareColor = Color.RED;
                    //System.out.println("Painted move");
                }
            }
        }
    }

    
    public void deselectPiece() {
        paintSquares();
    }

   
    public boolean checkThreatAt(int posX, int posY, boolean colorChoice) {
        for (Square[] squareArray : squareBoard) {
            for (Square square : squareArray) {
                if (square.getSquarePiece() != null && square.getSquarePiece().isBlack() != colorChoice) {
                    if (square.getSquarePiece().canMoveTo(squareBoard[posX][posY])){
                        square.squareColor = Color.RED;
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
