/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ankur.game.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;
import ankur.game.design.moves.FairyMoveSet;

/**
 *
 * @author Ankur Lamichhane
 */
public class Fairy  extends Piece {

    /**
     * Creates a fairy based on its color (black or white).
     *
     * @param colorChoice a boolean value defining the color of the piece (black if <em>true</em>, white otherwise).
     */
    public Fairy(boolean colorChoice) {
        super(colorChoice);
    }
    
    public void learnMoveSetFrom(Square referenceSquare, Board referenceBoard) {
        referenceMoveSet = new FairyMoveSet(referenceSquare, referenceBoard, this.isBlack);
    }
    
}
