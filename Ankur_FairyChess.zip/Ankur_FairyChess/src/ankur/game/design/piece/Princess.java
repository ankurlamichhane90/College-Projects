package ankur.game.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;
import ankur.game.design.moves.PrincessMoveSet;

/**
 *
 * @author Ankur Lamichhane
 */
public class Princess extends Piece {

    /**
     * Creates a princess based on its color (black or white).
     *
     * @param colorChoice a boolean value defining the color of the piece (black if <em>true</em>, white otherwise).
     */
    public Princess(boolean colorChoice) {
        super(colorChoice);
    }

    /**
     * Gets a specific MoveSet implementation to ease updating. This method is only called by a chessboard, right after
     * the piece's creation.
     *
     * @param referenceSquare the square to be used as reference for the MoveSet object.
     * @param referenceBoard  the chessboard to be used as reference for the MoveSet object.
     */
    public void learnMoveSetFrom(Square referenceSquare, Board referenceBoard) {
        referenceMoveSet = new PrincessMoveSet(referenceSquare, referenceBoard, this.isBlack);
    }
}
