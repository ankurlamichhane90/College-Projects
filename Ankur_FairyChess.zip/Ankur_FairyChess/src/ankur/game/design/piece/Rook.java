package ankur.game.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;
import ankur.game.design.moves.RookMoveSet;

/**
 *
 * @author Ankur Lamichhane
 */
public class Rook extends Piece {

    /**
     * Creates a rook based on its color (black or white).
     */
    public Rook(boolean colorChoice) {
        super(colorChoice);
    }

    /**
     * Gets a specific MoveSet implementation to ease updating. This method is only called by a chessboard, right after
     * the piece's creation.
     *
     * @param referenceSquare the square to be used as reference for the MoveSet object.
     * @param referenceBoard  the chessboard to be used as reference for the MoveSet object.
     */
    public void learnMoveSetFrom(Square referenceSquare, Board referenceBoard) {
        referenceMoveSet = new RookMoveSet(referenceSquare, referenceBoard, this.isBlack);
    }
}
