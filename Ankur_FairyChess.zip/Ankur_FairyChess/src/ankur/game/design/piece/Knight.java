package ankur.game.design.piece;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;
import ankur.game.design.moves.KnightMoveSet;

/**
 *
 * @author Ankur Lamichhane
 */
public class Knight extends Piece {

    /**
     * Creates a knight based on its color (black or white).
     *
     * @param colorChoice a boolean value defining the color of the piece (black if <em>true</em>, white otherwise).
     */
    public Knight(boolean colorChoice) {
        super(colorChoice);
    }

    /**
     * Gets a MoveSet implementation to ease updating. This method is only called by a chessboard.
     *
     * @param referenceSquare the square to be used as reference for the MoveSet object.
     * @param referenceBoard  the chessboard to be used as reference for the MoveSet object.
     */
    public void learnMoveSetFrom(Square referenceSquare, Board referenceBoard) {
        referenceMoveSet = new KnightMoveSet(referenceSquare, referenceBoard, isBlack);
    }
}
