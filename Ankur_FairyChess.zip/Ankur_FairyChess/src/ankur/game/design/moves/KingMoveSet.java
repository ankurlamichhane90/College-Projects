package ankur.game.design.moves;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;


public class KingMoveSet extends RoyalMoveSet {
    
   
    public KingMoveSet(Square referenceSquare, Board referenceBoard, boolean colorChoice) {
        super(referenceSquare, referenceBoard, colorChoice);
    }

   
    @Override
    protected void learnMoveSet() {
        addSquareWithReferenceAt(0, 1);
        addSquareWithReferenceAt(-1, 1);
        addSquareWithReferenceAt(1, 1);
        addSquareWithReferenceAt(1, 0);
        addSquareWithReferenceAt(-1, 0);
        addSquareWithReferenceAt(0, -1);
        addSquareWithReferenceAt(1, -1);
        addSquareWithReferenceAt(-1, -1);
    }

    private void addSquareWithReferenceAt(int distX, int distY) {
        addSquareIfNotThreatened(getRefX() + distX, getRefY() + distY);
    }
}
