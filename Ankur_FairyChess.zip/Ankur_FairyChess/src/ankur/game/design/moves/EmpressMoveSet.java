package ankur.game.design.moves;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;

/**
 *
 * @author Ankur Lamichhane
 */
public class EmpressMoveSet extends MoveSet {

    /**
     * Creates a new move Empress set having a square, a board and a color as reference.
     *
     * @param referenceSquare the square to be taken as reference for relative moves.
     * @param referenceBoard  the board to be taken as reference for moves.
     * @param colorChoice     the color choice of the piece, in case a piece has color limitations.
     */
    public EmpressMoveSet(Square referenceSquare, Board referenceBoard, boolean colorChoice) {
        super(referenceSquare, referenceBoard, colorChoice);
    }

    /**
     * Process the piece-specific algorithms to acquire the allowed squares to move to.
     */
    @Override
    protected void learnMoveSet() {
        MoveSet knightMoves = new KnightMoveSet(referenceSquare, referenceBoard, colorChoice);
        MoveSet rookMoves = new RookMoveSet(referenceSquare, referenceBoard, colorChoice);
        knightMoves.learnMoveSet();
        rookMoves.learnMoveSet();
        possibleMoves.addAll(knightMoves.getMoves());
        possibleMoves.addAll(rookMoves.getMoves());
    }
}
