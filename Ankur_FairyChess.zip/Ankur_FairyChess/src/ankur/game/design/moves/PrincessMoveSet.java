package ankur.game.design.moves;

import ankur.game.design.board.Board;
import ankur.game.design.board.Square;

/**
 *
 * @author Arpit Lamichhane
 */
public class PrincessMoveSet extends MoveSet {

    /**
     * Creates a new Princess move set having a square, a board and a color as reference.
     *
     * @param referenceSquare the square to be taken as reference for relative moves.
     * @param referenceBoard  the board to be taken as reference for moves.
     * @param colorChoice     the color choice of the piece, in case a piece has color limitations.
     */
    public PrincessMoveSet(Square referenceSquare, Board referenceBoard, boolean colorChoice) {
        super(referenceSquare, referenceBoard, colorChoice);
    }

    /**
     * Process the piece-specific algorithms to acquire the allowed squares to move to.
     */
    protected void learnMoveSet() {
        MoveSet knightMoves = new KnightMoveSet(referenceSquare, referenceBoard, colorChoice);
        MoveSet bishopMoves = new BishopMoveSet(referenceSquare, referenceBoard, colorChoice);
        knightMoves.learnMoveSet();
        bishopMoves.learnMoveSet();
        possibleMoves.addAll(knightMoves.getMoves());
        possibleMoves.addAll(bishopMoves.getMoves());
    }
}
