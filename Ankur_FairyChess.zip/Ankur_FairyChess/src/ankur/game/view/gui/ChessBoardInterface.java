package ankur.game.view.gui;

import ankur.game.design.board.Board;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Ankur Lamichhane
 */
public class ChessBoardInterface extends BoardGUI {

    /**
     * Creates a complete GUI for the traditional chessboard game.     
     */
    public ChessBoardInterface(Board chessModel) {
        super(chessModel);
    }

    /**
     * Creates a JPanel with a GridLayout set specifically for the chess interface.
     */
    protected void setChessLayout() {
        chessLayout = new GridLayout(8, 0);
    }

    /**
     * Creates a JButton for each square on the board.
     */
    protected void setChessBoardAsButtons() {
        buttons = new JButton[8][8];
        for (int posY = 7; posY >= 0; posY--) {
            for (int posX = 0; posX < 8; posX++) {
                buttons[posX][posY] = newSquareButton(posX, posY);
                chessPanel.add(buttons[posX][posY]);
            }
        }
    }

    /**
     * Resets colors on the chessboard squares.
     */
    protected void resetColors() {
        for (int xPos = 0; xPos < 8; xPos++) {
            for (int yPos = 0; yPos < 8; yPos++) {
                final JButton button = buttons[xPos][yPos];
                button.setBackground(chessModel.getSquareAt(xPos, yPos).getSquareColor());
                button.setIcon(null);
                addPieceAt(button, xPos, yPos);
            }
        }
    }

    /**
     * Creates a new JButton directly related to a square on the chessboard.
     *
     * @param posX X-coordinate of a square on the chessboard.
     * @param posY Y-coordinate of a square on the chessboard.
     * @return a JButton with all the needed properties of the square.
     */
    private JButton newSquareButton(int posX, int posY) {
        JButton newButton = new JButton();
        newButton.setMinimumSize(new Dimension(110, 110));
        newButton.setPreferredSize(new Dimension(110, 110));
        newButton.setBorder(new LineBorder(Color.BLACK));
        newButton.setBackground(chessModel.getSquareAt(posX, posY).getSquareColor());
        addPieceAt(newButton, posX, posY);
        return newButton;
    }

    /**
     * 
     *
     * @param button a button that may receive the piece image.
     * @param posX   X-coordinate of the square on the board where a piece may be.
     * @param posY   Y-coordinate of the square on the board where a piece may be.
     */
    private void addPieceAt(JButton button, int posX, int posY) {
        if (chessModel.hasPieceAt(posX, posY)) {
            try {
                Image img = ImageIO.read(new File(chessModel.getSquareAt(posX, posY).getSquarePiece().getPathToImage()));
                button.setIcon(new ImageIcon(img));
            } catch (IOException e) {
                System.out.println("You tried to draw a non-existent image for a piece.");
            }
        }
    }

}