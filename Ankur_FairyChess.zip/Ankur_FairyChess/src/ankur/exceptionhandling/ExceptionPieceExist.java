package ankur.exceptionhandling;


public class ExceptionPieceExist extends RuntimeException {

    
    public ExceptionPieceExist(String message) {
        super(message);
    }
}