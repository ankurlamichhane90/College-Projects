package ankur.exceptionhandling;


public class ExceptionInGame extends RuntimeException {

   
    public ExceptionInGame(String message) {
        super(message);
    }
}