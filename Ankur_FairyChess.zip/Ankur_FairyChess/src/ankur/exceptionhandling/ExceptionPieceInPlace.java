package ankur.exceptionhandling;


public class ExceptionPieceInPlace extends RuntimeException {

    
    public ExceptionPieceInPlace(String message) {
        super(message);
    }
}